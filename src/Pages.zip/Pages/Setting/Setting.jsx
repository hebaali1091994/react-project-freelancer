import React from 'react'
import Account from './../../Components/Account/Account';

const Setting = () => {
    return (
        <div>
  <div class="Setting bg-light mt-5">
    <div class="container">
    <div class="d-flex align-items-start">

                        {/* <div class="btn-group-vertical w-100">
                    <Link to="/Profile" class="btn text-primary text-start">Profile</Link>
                    <Link to="/Email" class="btn text-primary text-start">Email & Notifications</Link>
                    <Link to="/Membership" class="btn text-primary text-start">Membership</Link>
                    <Link to="/Password" class="btn text-primary text-start">Password</Link>
                    <Link to="/Payment" class="btn text-primary text-start">Payment & Financial</Link>
                    <Link to="/AccountSecurity" class="btn text-primary text-start">Account Security</Link>
                    <Link  to="/Trust" class="btn text-primary text-start">Trust & Verification</Link>
                    <Link to="/Account" class="btn btn-outline-primary text-start active">Account</Link>
                </div> */}
  <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Email & Notifications</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Membership</button>
    <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">Password</button>
    <button class="nav-link" id="v-pills-Payment-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Payment" type="button" role="tab" aria-controls="v-pills-Payment" aria-selected="false">Payment & Financials</button>
    <button class="nav-link" id="v-pills-Security-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Security" type="button" role="tab" aria-controls="v-pills-Security" aria-selected="false">Account Security</button>
    <button class="nav-link" id="v-pills-Trust-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Trust" type="button" role="tab" aria-controls="v-pills-Trust" aria-selected="false">Trust & Verification</button>
    <button class="nav-link" id="v-pills-Account-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Account" type="button" role="tab" aria-controls="v-pills-Account" aria-selected="false">Account</button>
  </div>
  <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab"><Account/></div>
    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">Profile</div>
    <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">Hello</div>
    <div class="tab-pane fade" id="v-pills-Payment" role="tabpanel" aria-labelledby="v-pills-Payment-tab">...</div>
     <div class="tab-pane fade" id="v-pills-Payment" role="tabpanel" aria-labelledby="v-pills-Payment-tab">...</div>
      <div class="tab-pane fade" id="v-pills-Security" role="tabpanel" aria-labelledby="v-pills-Security-tab">Account</div>
       <div class="tab-pane fade" id="v-pills-Trust" role="tabpanel" aria-labelledby="v-pills-Trust-tab">Trust</div>
        <div class="tab-pane fade" id="v-pills-Account" role="tabpanel" aria-labelledby="v-pills-Account-tab">Account</div>
  </div>
</div>
</div></div>

        </div>
    )
}

export default Setting
